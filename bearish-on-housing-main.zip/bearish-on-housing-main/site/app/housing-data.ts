export type Metric = "owner" | "renter";

export type TrendPoint = {
  year: number;
  owner: number;
  renter: number | null;
};

export type Metro = {
  name: string;
  short: string;
  owner: number;
  renter: number;
  homeValue: number;
  rent: number;
  yearsToSave: number;
  homeGrowth: number;
  rentGrowth: number;
  trend: Array<{ year: number; owner: number; renter: number }>;
};

export const nationalTrend: TrendPoint[] = [
  {
    "year": 2012,
    "owner": 20.9,
    "renter": null
  },
  {
    "year": 2013,
    "owner": 24,
    "renter": null
  },
  {
    "year": 2014,
    "owner": 22.9,
    "renter": null
  },
  {
    "year": 2015,
    "owner": 23.4,
    "renter": 25.1
  },
  {
    "year": 2016,
    "owner": 24.1,
    "renter": 25.1
  },
  {
    "year": 2017,
    "owner": 24.2,
    "renter": 25.2
  },
  {
    "year": 2018,
    "owner": 25.7,
    "renter": 25.2
  },
  {
    "year": 2019,
    "owner": 24,
    "renter": 25.3
  },
  {
    "year": 2020,
    "owner": 23,
    "renter": 24.9
  },
  {
    "year": 2021,
    "owner": 25.9,
    "renter": 27.5
  },
  {
    "year": 2022,
    "owner": 34.7,
    "renter": 27.4
  },
  {
    "year": 2023,
    "owner": 35.9,
    "renter": 27.2
  },
  {
    "year": 2024,
    "owner": 35,
    "renter": 26.7
  },
  {
    "year": 2025,
    "owner": 32.7,
    "renter": 26.4
  },
  {
    "year": 2026,
    "owner": 32.3,
    "renter": 26.3
  }
];

export const metros: Metro[] = [
  {
    "name": "Atlanta, GA",
    "short": "Atlanta",
    "owner": 30.66,
    "renter": 22.26,
    "homeValue": 376108,
    "rent": 1808,
    "yearsToSave": 8,
    "homeGrowth": 118.3,
    "rentGrowth": 83,
    "trend": [
      {
        "year": 2015,
        "owner": 19.91,
        "renter": 20.03
      },
      {
        "year": 2016,
        "owner": 20.94,
        "renter": 20.39
      },
      {
        "year": 2017,
        "owner": 21.13,
        "renter": 20.65
      },
      {
        "year": 2018,
        "owner": 23.41,
        "renter": 21.28
      },
      {
        "year": 2019,
        "owner": 22.39,
        "renter": 21.92
      },
      {
        "year": 2020,
        "owner": 21.23,
        "renter": 22.06
      },
      {
        "year": 2021,
        "owner": 24.86,
        "renter": 25.34
      },
      {
        "year": 2022,
        "owner": 34.03,
        "renter": 24.45
      },
      {
        "year": 2023,
        "owner": 34.78,
        "renter": 23.27
      },
      {
        "year": 2024,
        "owner": 33.98,
        "renter": 22.65
      },
      {
        "year": 2025,
        "owner": 31.22,
        "renter": 22.45
      },
      {
        "year": 2026,
        "owner": 30.66,
        "renter": 22.26
      }
    ]
  },
  {
    "name": "Boston, MA",
    "short": "Boston",
    "owner": 43.45,
    "renter": 29.74,
    "homeValue": 713764,
    "rent": 3098,
    "yearsToSave": 11,
    "homeGrowth": 91.3,
    "rentGrowth": 54.5,
    "trend": [
      {
        "year": 2015,
        "owner": 33.35,
        "renter": 31.46
      },
      {
        "year": 2016,
        "owner": 34.67,
        "renter": 31.25
      },
      {
        "year": 2017,
        "owner": 34.45,
        "renter": 31.03
      },
      {
        "year": 2018,
        "owner": 36.73,
        "renter": 30.79
      },
      {
        "year": 2019,
        "owner": 33.88,
        "renter": 30.97
      },
      {
        "year": 2020,
        "owner": 31.75,
        "renter": 27.6
      },
      {
        "year": 2021,
        "owner": 34.01,
        "renter": 30.35
      },
      {
        "year": 2022,
        "owner": 44.87,
        "renter": 30.88
      },
      {
        "year": 2023,
        "owner": 47.31,
        "renter": 30.91
      },
      {
        "year": 2024,
        "owner": 46.57,
        "renter": 30.23
      },
      {
        "year": 2025,
        "owner": 43.99,
        "renter": 29.87
      },
      {
        "year": 2026,
        "owner": 43.45,
        "renter": 29.74
      }
    ]
  },
  {
    "name": "Chicago, IL",
    "short": "Chicago",
    "owner": 33.66,
    "renter": 26.84,
    "homeValue": 338685,
    "rent": 2132,
    "yearsToSave": 7,
    "homeGrowth": 75.2,
    "rentGrowth": 57,
    "trend": [
      {
        "year": 2015,
        "owner": 23.98,
        "renter": 25.34
      },
      {
        "year": 2016,
        "owner": 24.82,
        "renter": 25.25
      },
      {
        "year": 2017,
        "owner": 24.46,
        "renter": 25.05
      },
      {
        "year": 2018,
        "owner": 25.14,
        "renter": 24.48
      },
      {
        "year": 2019,
        "owner": 23.59,
        "renter": 24.73
      },
      {
        "year": 2020,
        "owner": 22.09,
        "renter": 23.2
      },
      {
        "year": 2021,
        "owner": 23.89,
        "renter": 24.92
      },
      {
        "year": 2022,
        "owner": 30.27,
        "renter": 25.34
      },
      {
        "year": 2023,
        "owner": 31.78,
        "renter": 25.63
      },
      {
        "year": 2024,
        "owner": 31.92,
        "renter": 26.25
      },
      {
        "year": 2025,
        "owner": 33.83,
        "renter": 26.75
      },
      {
        "year": 2026,
        "owner": 33.66,
        "renter": 26.84
      }
    ]
  },
  {
    "name": "Dallas, TX",
    "short": "Dallas",
    "owner": 31.01,
    "renter": 19.9,
    "homeValue": 362142,
    "rent": 1630,
    "yearsToSave": 7,
    "homeGrowth": 105.5,
    "rentGrowth": 56.3,
    "trend": [
      {
        "year": 2015,
        "owner": 23.58,
        "renter": 20.67
      },
      {
        "year": 2016,
        "owner": 25.74,
        "renter": 20.91
      },
      {
        "year": 2017,
        "owner": 26.12,
        "renter": 20.9
      },
      {
        "year": 2018,
        "owner": 27.49,
        "renter": 20.87
      },
      {
        "year": 2019,
        "owner": 26.12,
        "renter": 20.99
      },
      {
        "year": 2020,
        "owner": 24.98,
        "renter": 20.81
      },
      {
        "year": 2021,
        "owner": 28.54,
        "renter": 23.43
      },
      {
        "year": 2022,
        "owner": 37.95,
        "renter": 23.06
      },
      {
        "year": 2023,
        "owner": 36.59,
        "renter": 21.8
      },
      {
        "year": 2024,
        "owner": 35.12,
        "renter": 20.61
      },
      {
        "year": 2025,
        "owner": 31.57,
        "renter": 20.02
      },
      {
        "year": 2026,
        "owner": 31.01,
        "renter": 19.9
      }
    ]
  },
  {
    "name": "Houston, TX",
    "short": "Houston",
    "owner": 30.17,
    "renter": 22.66,
    "homeValue": 304622,
    "rent": 1620,
    "yearsToSave": 7,
    "homeGrowth": 70.5,
    "rentGrowth": 35.6,
    "trend": [
      {
        "year": 2015,
        "owner": 23.71,
        "renter": 23.66
      },
      {
        "year": 2016,
        "owner": 25.66,
        "renter": 23.28
      },
      {
        "year": 2017,
        "owner": 25.44,
        "renter": 23.57
      },
      {
        "year": 2018,
        "owner": 26.51,
        "renter": 23.23
      },
      {
        "year": 2019,
        "owner": 22.82,
        "renter": 23.38
      },
      {
        "year": 2020,
        "owner": 21.96,
        "renter": 23.16
      },
      {
        "year": 2021,
        "owner": 26.06,
        "renter": 25.1
      },
      {
        "year": 2022,
        "owner": 33.13,
        "renter": 24.48
      },
      {
        "year": 2023,
        "owner": 33.72,
        "renter": 24
      },
      {
        "year": 2024,
        "owner": 32.68,
        "renter": 23.62
      },
      {
        "year": 2025,
        "owner": 30.67,
        "renter": 22.85
      },
      {
        "year": 2026,
        "owner": 30.17,
        "renter": 22.66
      }
    ]
  },
  {
    "name": "Los Angeles, CA",
    "short": "Los Angeles",
    "owner": 67.46,
    "renter": 33.91,
    "homeValue": 954296,
    "rent": 2884,
    "yearsToSave": 19,
    "homeGrowth": 88.6,
    "rentGrowth": 65.6,
    "trend": [
      {
        "year": 2015,
        "owner": 47.36,
        "renter": 34.69
      },
      {
        "year": 2016,
        "owner": 48.99,
        "renter": 34.84
      },
      {
        "year": 2017,
        "owner": 50.53,
        "renter": 34.92
      },
      {
        "year": 2018,
        "owner": 56.12,
        "renter": 34.62
      },
      {
        "year": 2019,
        "owner": 51.07,
        "renter": 34.82
      },
      {
        "year": 2020,
        "owner": 47.41,
        "renter": 32.7
      },
      {
        "year": 2021,
        "owner": 53.37,
        "renter": 35.85
      },
      {
        "year": 2022,
        "owner": 72.12,
        "renter": 36.21
      },
      {
        "year": 2023,
        "owner": 75.26,
        "renter": 35.21
      },
      {
        "year": 2024,
        "owner": 74.26,
        "renter": 34.51
      },
      {
        "year": 2025,
        "owner": 68.36,
        "renter": 34.21
      },
      {
        "year": 2026,
        "owner": 67.46,
        "renter": 33.91
      }
    ]
  },
  {
    "name": "Miami, FL",
    "short": "Miami",
    "owner": 46.49,
    "renter": 37.25,
    "homeValue": 469603,
    "rent": 2654,
    "yearsToSave": 11,
    "homeGrowth": 119.6,
    "rentGrowth": 81.3,
    "trend": [
      {
        "year": 2015,
        "owner": 33.39,
        "renter": 36.23
      },
      {
        "year": 2016,
        "owner": 35.55,
        "renter": 35.75
      },
      {
        "year": 2017,
        "owner": 35.43,
        "renter": 35
      },
      {
        "year": 2018,
        "owner": 37.7,
        "renter": 34.43
      },
      {
        "year": 2019,
        "owner": 35.32,
        "renter": 34.28
      },
      {
        "year": 2020,
        "owner": 33.38,
        "renter": 33.71
      },
      {
        "year": 2021,
        "owner": 37.29,
        "renter": 40.99
      },
      {
        "year": 2022,
        "owner": 51.42,
        "renter": 41.8
      },
      {
        "year": 2023,
        "owner": 53.87,
        "renter": 39.78
      },
      {
        "year": 2024,
        "owner": 52.43,
        "renter": 38.41
      },
      {
        "year": 2025,
        "owner": 47.19,
        "renter": 37.44
      },
      {
        "year": 2026,
        "owner": 46.49,
        "renter": 37.25
      }
    ]
  },
  {
    "name": "New York, NY",
    "short": "New York",
    "owner": 55.23,
    "renter": 37.13,
    "homeValue": 706888,
    "rent": 3258,
    "yearsToSave": 13,
    "homeGrowth": 73.3,
    "rentGrowth": 51.3,
    "trend": [
      {
        "year": 2015,
        "owner": 42.99,
        "renter": 36.66
      },
      {
        "year": 2016,
        "owner": 44.77,
        "renter": 36.41
      },
      {
        "year": 2017,
        "owner": 44.29,
        "renter": 34.95
      },
      {
        "year": 2018,
        "owner": 46.53,
        "renter": 34.7
      },
      {
        "year": 2019,
        "owner": 42.95,
        "renter": 35.17
      },
      {
        "year": 2020,
        "owner": 40.34,
        "renter": 31
      },
      {
        "year": 2021,
        "owner": 44.12,
        "renter": 35.44
      },
      {
        "year": 2022,
        "owner": 55.56,
        "renter": 36.76
      },
      {
        "year": 2023,
        "owner": 56.61,
        "renter": 36.57
      },
      {
        "year": 2024,
        "owner": 57.36,
        "renter": 36.69
      },
      {
        "year": 2025,
        "owner": 55.59,
        "renter": 37.17
      },
      {
        "year": 2026,
        "owner": 55.23,
        "renter": 37.13
      }
    ]
  },
  {
    "name": "Philadelphia, PA",
    "short": "Philadelphia",
    "owner": 32.23,
    "renter": 23.26,
    "homeValue": 376063,
    "rent": 1859,
    "yearsToSave": 8,
    "homeGrowth": 84.2,
    "rentGrowth": 57.7,
    "trend": [
      {
        "year": 2015,
        "owner": 22.65,
        "renter": 22.3
      },
      {
        "year": 2016,
        "owner": 23.58,
        "renter": 22.33
      },
      {
        "year": 2017,
        "owner": 22.88,
        "renter": 22.3
      },
      {
        "year": 2018,
        "owner": 24.99,
        "renter": 22.09
      },
      {
        "year": 2019,
        "owner": 24.56,
        "renter": 22.51
      },
      {
        "year": 2020,
        "owner": 21.74,
        "renter": 21.77
      },
      {
        "year": 2021,
        "owner": 23.66,
        "renter": 23.61
      },
      {
        "year": 2022,
        "owner": 31.1,
        "renter": 23.31
      },
      {
        "year": 2023,
        "owner": 33.32,
        "renter": 23.31
      },
      {
        "year": 2024,
        "owner": 33.38,
        "renter": 23.32
      },
      {
        "year": 2025,
        "owner": 32.59,
        "renter": 23.25
      },
      {
        "year": 2026,
        "owner": 32.23,
        "renter": 23.26
      }
    ]
  },
  {
    "name": "Washington, DC",
    "short": "Washington",
    "owner": 32.84,
    "renter": 21.07,
    "homeValue": 572410,
    "rent": 2331,
    "yearsToSave": 9,
    "homeGrowth": 54,
    "rentGrowth": 39.7,
    "trend": [
      {
        "year": 2015,
        "owner": 26.57,
        "renter": 22.28
      },
      {
        "year": 2016,
        "owner": 27.02,
        "renter": 21.99
      },
      {
        "year": 2017,
        "owner": 26.34,
        "renter": 21.72
      },
      {
        "year": 2018,
        "owner": 27.83,
        "renter": 21.65
      },
      {
        "year": 2019,
        "owner": 25.9,
        "renter": 21.63
      },
      {
        "year": 2020,
        "owner": 24.43,
        "renter": 20.4
      },
      {
        "year": 2021,
        "owner": 26.46,
        "renter": 22.11
      },
      {
        "year": 2022,
        "owner": 34.37,
        "renter": 21.57
      },
      {
        "year": 2023,
        "owner": 35.38,
        "renter": 21.54
      },
      {
        "year": 2024,
        "owner": 35.54,
        "renter": 21.76
      },
      {
        "year": 2025,
        "owner": 33.38,
        "renter": 21.23
      },
      {
        "year": 2026,
        "owner": 32.84,
        "renter": 21.07
      }
    ]
  }
];

export const coverage = [
  { metric: "Home values & owner burden", start: "Jan 2012", end: "Feb 2026", missing: "0%" },
  { metric: "Rent index & renter burden", start: "Jan 2015", end: "Feb 2026", missing: "21.2%" },
  { metric: "Inventory & days on market", start: "Mar 2018", end: "Feb 2026", missing: "43.5%" },
  { metric: "New construction sales", start: "Jan 2018", end: "Jan 2026", missing: "42.9%" },
  { metric: "Sale-to-list ratio", start: "Jan 2018", end: "Jan 2026", missing: "43.1%" },
];

