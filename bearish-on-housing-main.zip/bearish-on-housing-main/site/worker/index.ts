import handler from "vinext/server/app-router-entry";

const worker = {
  fetch(request: Request) {
    return handler.fetch(request);
  },
};

export default worker;
