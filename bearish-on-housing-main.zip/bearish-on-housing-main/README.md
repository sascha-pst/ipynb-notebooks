# Bearish on Housing

An interactive, auditable account of housing affordability across the United States and ten major metropolitan areas.

**[Explore the live project](https://bearish-on-housing.orchidgirl.chatgpt.site)**

The project is designed to help readers:

- understand the national affordability story in a few minutes;
- compare buying and renting burdens across as many as five metros at once; and
- audit the source fields, time coverage, missingness, and benchmark assumptions behind the analysis.

## What the dashboard shows

The current data run covers January 2012 through February 2026. The headline comparison uses the share of median household income needed to buy the typical home or lease the typical rental. A 30% income share is shown as the conventional cost-burden benchmark—not as a universal rule for every household.

The ten-metro comparison includes Atlanta, Boston, Chicago, Dallas, Houston, Los Angeles, Miami, New York, Philadelphia, and Washington, D.C.

## Repository structure

- `site/` — the interactive web application
- `top10_metros_clean.csv` — monthly panel for the ten studied metros
- `us_all_datasets_cleaned.csv` — national monthly series used for context
- existing notebooks and exploratory artifacts remain available for provenance

## Run the site locally

Requires Node.js 22.13 or newer.

```bash
cd site
npm ci
npm run dev
```

Then open the local URL printed by the development server.

Validation commands:

```bash
npm run lint
npm run build
```

## Deploy with Cloudflare Workers

Connect this GitHub repository in **Workers & Pages → Create → Import a repository**, then use:

- production branch: `main`
- root directory: `site`
- build command: `npm run build`
- deploy command: `npx wrangler deploy --config dist/server/wrangler.json`
- preview deploy command: `npx wrangler versions upload --config dist/server/wrangler.json`

The committed `wrangler.jsonc` names the Worker `bearish-on-housing`. If you choose a different Worker name in Cloudflare, update the `name` field to match. No runtime secrets or database bindings are required.

## Data and methodology

The analysis uses public series from [Zillow Research](https://www.zillow.com/research/data/), including typical home values, observed rents, and Zillow affordability measures. The interface uses the fields actually present in the repository's cleaned CSVs and reports structural gaps in coverage rather than silently interpolating them.

Coverage differs by measure:

- home values and new-owner burden: January 2012–February 2026;
- rent and new-renter burden: January 2015–February 2026;
- inventory and days to pending: March 2018–February 2026;
- construction: January 2018–January 2026; and
- sale-to-list ratio: January 2018–January 2026.

The dashboard is descriptive. It does not forecast prices or provide financial advice. “Bearish” refers to structurally high affordability burdens, not a claim that every metro is currently deteriorating.

## Current analytical takeaway

At the latest observation in the included data, all ten studied metros require at least 30% of median household income for a newly purchased typical home. Only Los Angeles, Miami, and New York cross the same threshold for a typical new rental. The gap is large, but the trend is not uniform across places or through time—that is why the site emphasizes comparison and auditability.
