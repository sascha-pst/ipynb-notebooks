"use client";

import { useMemo, useState } from "react";
import { coverage, metros, nationalTrend, type Metric } from "./housing-data";

const COLORS = ["#315b73", "#bd5f3d", "#737b5c", "#9b6b82", "#b38b47"];
const DEFAULT_METROS = ["Los Angeles, CA", "Miami, FL", "Atlanta, GA"];

const money = new Intl.NumberFormat("en-US", {
  style: "currency",
  currency: "USD",
  maximumFractionDigits: 0,
});

function linePath(
  values: Array<{ x: number; y: number }>,
  width: number,
  height: number,
  minY: number,
  maxY: number,
) {
  const padX = 46;
  const padTop = 24;
  const padBottom = 36;
  const maxX = Math.max(...values.map((point) => point.x), 1);
  return values
    .map((point, index) => {
      const x = padX + (point.x / maxX) * (width - padX - 18);
      const y =
        padTop +
        ((maxY - point.y) / (maxY - minY)) *
          (height - padTop - padBottom);
      return `${index === 0 ? "M" : "L"}${x.toFixed(1)},${y.toFixed(1)}`;
    })
    .join(" ");
}

function NationalChart() {
  const width = 860;
  const height = 330;
  const minY = 15;
  const maxY = 42;
  const owner = nationalTrend.map((d, i) => ({ x: i, y: d.owner }));
  const renter = nationalTrend
    .map((d, i) => ({ x: i, y: d.renter }))
    .filter((d): d is { x: number; y: number } => d.y !== null);
  const plotY = (value: number) =>
    24 + ((maxY - value) / (maxY - minY)) * (height - 60);
  const peakX = 46 + (11 / 14) * (width - 64);

  return (
    <div className="chart-shell" aria-label="National housing-cost burden from 2012 through 2026">
      <div className="chart-head">
        <div>
          <p className="micro-label">National timeline</p>
          <h3>Ownership broke away from renting after 2021.</h3>
        </div>
        <div className="legend" aria-label="Chart legend">
          <span><i className="legend-line owner" />New owner</span>
          <span><i className="legend-line renter" />New renter</span>
          <span><i className="legend-line benchmark" />30% benchmark</span>
        </div>
      </div>
      <svg viewBox={`0 0 ${width} ${height}`} role="img" aria-labelledby="national-chart-title">
        <title id="national-chart-title">National owner and renter affordability burden by year</title>
        {[20, 30, 40].map((tick) => (
          <g key={tick}>
            <line
              x1="46"
              x2={width - 18}
              y1={plotY(tick)}
              y2={plotY(tick)}
              className={tick === 30 ? "benchmark-grid" : "chart-grid"}
            />
            <text x="8" y={plotY(tick) + 4} className="axis-label">{tick}%</text>
          </g>
        ))}
        <path d={linePath(owner, width, height, minY, maxY)} className="data-line owner" />
        <path d={linePath(renter, width, height, minY, maxY)} className="data-line renter" />
        <line x1={peakX} x2={peakX} y1="38" y2={plotY(38.4)} className="annotation-stem" />
        <circle cx={peakX} cy={plotY(38.4)} r="5" className="peak-dot" />
        <g transform={`translate(${peakX - 67} 18)`}>
          <rect width="134" height="25" rx="4" className="annotation-box" />
          <text x="67" y="17" textAnchor="middle" className="annotation-text">38.4% · Oct 2023</text>
        </g>
        {nationalTrend.map((point, i) => (
          <text
            key={point.year}
            x={46 + (i / 14) * (width - 64)}
            y={height - 10}
            textAnchor="middle"
            className={point.year % 2 === 0 ? "axis-year" : "axis-year hide-small"}
          >
            {String(point.year).slice(2)}
          </text>
        ))}
      </svg>
      <p className="chart-note">
        Share of median household income needed to newly buy or lease the typical home. Renter series begins in 2015.
      </p>
    </div>
  );
}

function MetroTrend({ selected, metric }: { selected: string[]; metric: Metric }) {
  const width = 820;
  const height = 360;
  const minY = 15;
  const maxY = 80;
  const data = selected.map((name) => metros.find((metro) => metro.name === name)!);
  const plotY = (value: number) => 24 + ((maxY - value) / (maxY - minY)) * (height - 64);

  return (
    <div className="trend-chart">
      <svg viewBox={`0 0 ${width} ${height}`} role="img" aria-labelledby="metro-chart-title">
        <title id="metro-chart-title">Selected metro affordability trends from 2015 to 2026</title>
        {[20, 30, 40, 50, 60, 70].map((tick) => (
          <g key={tick}>
            <line x1="46" x2={width - 22} y1={plotY(tick)} y2={plotY(tick)} className={tick === 30 ? "benchmark-grid" : "chart-grid"} />
            <text x="8" y={plotY(tick) + 4} className="axis-label">{tick}%</text>
          </g>
        ))}
        {data.map((metro, index) => {
          const values = metro.trend.map((point, i) => ({ x: i, y: point[metric] }));
          return (
            <g key={metro.name}>
              <path
                d={linePath(values, width, height, minY, maxY)}
                className="metro-line"
                style={{ stroke: COLORS[index] }}
              />
              {values.map((point, i) => {
                const x = 46 + (i / 11) * (width - 64);
                const y = plotY(point.y);
                return (
                  <circle key={metro.name + i} cx={x} cy={y} r="3.4" style={{ fill: COLORS[index] }}>
                    <title>{metro.short}, {metro.trend[i].year}: {point.y.toFixed(1)}%</title>
                  </circle>
                );
              })}
            </g>
          );
        })}
        {Array.from({ length: 12 }, (_, i) => 2015 + i).map((year, i) => (
          <text key={year} x={46 + (i / 11) * (width - 64)} y={height - 10} textAnchor="middle" className="axis-year">
            {String(year).slice(2)}
          </text>
        ))}
      </svg>
      <div className="metro-legend">
        {data.map((metro, index) => (
          <span key={metro.name}><i style={{ background: COLORS[index] }} />{metro.short}</span>
        ))}
      </div>
    </div>
  );
}

export default function Home() {
  const [metric, setMetric] = useState<Metric>("owner");
  const [selected, setSelected] = useState(DEFAULT_METROS);
  const [focusName, setFocusName] = useState("Los Angeles, CA");

  const focusMetro = metros.find((metro) => metro.name === focusName) ?? metros[0];
  const ranking = useMemo(
    () => [...metros].sort((a, b) => b[metric] - a[metric]),
    [metric],
  );

  const toggleMetro = (name: string) => {
    setSelected((current) => {
      if (current.includes(name)) {
        if (current.length === 1) return current;
        return current.filter((metro) => metro !== name);
      }
      if (current.length >= 5) return current;
      return [...current, name];
    });
    setFocusName(name);
  };

  return (
    <main>
      <header className="site-header">
        <a href="#top" className="wordmark">Bearish on Housing</a>
        <nav aria-label="Primary navigation">
          <a href="#story">Story</a>
          <a href="#compare">Compare</a>
          <a href="#method">Method</a>
        </nav>
      </header>

      <section className="hero" id="top">
        <div className="hero-copy">
          <p className="eyebrow">U.S. housing affordability · 2012–2026</p>
          <h1>Buying got less brutal.<br />It didn’t get affordable.</h1>
          <p className="hero-lede">
            New-owner costs peaked at 38.4% of median income in 2023. They have eased—but every metro in this study still sits at or above the 30% affordability benchmark.
          </p>
          <a className="primary-button" href="#compare">Explore the metros <span>→</span></a>
        </div>
        <div className="hero-art" aria-hidden="true">
          {/* The generated editorial artwork is decorative; direct static delivery
              avoids an unnecessary image-proxy hop in the edge runtime. */}
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src="/human-city-hero.webp" alt="" width="1400" height="799" />
        </div>
      </section>

      <section className="kpi-strip" aria-label="Latest national housing affordability metrics">
        <article><span className="kpi-icon blue">⌂</span><div><strong>32.3%</strong><p>Owner burden</p></div></article>
        <article><span className="kpi-icon clay">▦</span><div><strong>26.3%</strong><p>Renter burden</p></div></article>
        <article><span className="kpi-icon sage">⌖</span><div><strong>10</strong><p>Metros studied</p></div></article>
      </section>

      <section className="story-section" id="story">
        <div className="section-intro">
          <p className="eyebrow">The national story</p>
          <h2>The gap opened fast—and has not closed.</h2>
          <p>
            Buying and renting consumed similar shares of income through much of the late 2010s. Rising prices and borrowing costs then pushed new-owner burden sharply higher. The retreat since 2023 matters, but 32.3% still crosses the conventional affordability line.
          </p>
        </div>
        <NationalChart />
      </section>

      <section className="findings" aria-label="Key findings">
        <article><span>01</span><h3>Relief is not affordability.</h3><p>National owner burden fell 6.1 percentage points from the October 2023 peak, yet remains above the 30% benchmark.</p></article>
        <article><span>02</span><h3>The pain is uneven.</h3><p>Los Angeles requires 67.5% of median income to buy the typical home; Houston sits near the threshold at 30.2%.</p></article>
        <article><span>03</span><h3>Renting is not universally affordable.</h3><p>Miami, New York, and Los Angeles remain above 30% for new renters, while the other seven metros fall below it.</p></article>
      </section>

      <section className="compare-section" id="compare">
        <div className="section-intro compare-intro">
          <div>
            <p className="eyebrow">Compare metros</p>
            <h2>One national market. Ten different realities.</h2>
          </div>
          <div className="segmented" aria-label="Choose affordability measure">
            <button className={metric === "owner" ? "active" : ""} onClick={() => setMetric("owner")} aria-pressed={metric === "owner"}>Buying</button>
            <button className={metric === "renter" ? "active" : ""} onClick={() => setMetric("renter")} aria-pressed={metric === "renter"}>Renting</button>
          </div>
        </div>

        <div className="compare-layout">
          <aside className="metro-picker">
            <div className="picker-head"><h3>Choose up to five</h3><span>{selected.length}/5</span></div>
            <div className="metro-buttons">
              {metros.map((metro) => (
                <button
                  key={metro.name}
                  className={selected.includes(metro.name) ? "selected" : ""}
                  onClick={() => toggleMetro(metro.name)}
                  aria-pressed={selected.includes(metro.name)}
                >
                  <span>{metro.short}</span><strong>{metro[metric].toFixed(1)}%</strong>
                </button>
              ))}
            </div>
            <p className="picker-note">Select at least one metro. The chart supports up to five for legibility.</p>
          </aside>

          <div className="comparison-panel">
            <div className="panel-heading">
              <div><p className="micro-label">2015–2026</p><h3>{metric === "owner" ? "New-owner" : "New-renter"} burden over time</h3></div>
              <p>Percent of median household income</p>
            </div>
            <MetroTrend selected={selected} metric={metric} />
          </div>
        </div>

        <div className="snapshot-grid">
          <div className="ranking-card">
            <div className="panel-heading"><div><p className="micro-label">February 2026</p><h3>Current burden ranking</h3></div><span>30% benchmark</span></div>
            <div className="bar-list">
              {ranking.map((metro) => (
                <button key={metro.name} onClick={() => setFocusName(metro.name)} className={focusName === metro.name ? "focused" : ""}>
                  <span>{metro.short}</span>
                  <i><b style={{ width: `${Math.min((metro[metric] / 75) * 100, 100)}%` }} /></i>
                  <strong>{metro[metric].toFixed(1)}%</strong>
                </button>
              ))}
            </div>
          </div>

          <article className="metro-detail">
            <label htmlFor="focus-metro">Metro detail</label>
            <select id="focus-metro" value={focusName} onChange={(event) => setFocusName(event.target.value)}>
              {metros.map((metro) => <option key={metro.name}>{metro.name}</option>)}
            </select>
            <h3>{focusMetro.short}</h3>
            <p className="detail-status">
              {focusMetro[metric] >= 30 ? "Above" : "Below"} the {metric === "owner" ? "owner" : "renter"} affordability benchmark
            </p>
            <dl>
              <div><dt>Typical home</dt><dd>{money.format(focusMetro.homeValue)}</dd></div>
              <div><dt>Typical rent</dt><dd>{money.format(focusMetro.rent)} / mo</dd></div>
              <div><dt>Years to save</dt><dd>{focusMetro.yearsToSave}</dd></div>
              <div><dt>Home-value growth</dt><dd>+{focusMetro.homeGrowth}% <small>since 2015</small></dd></div>
              <div><dt>Rent growth</dt><dd>+{focusMetro.rentGrowth}% <small>since 2015</small></dd></div>
            </dl>
          </article>
        </div>
      </section>

      <section className="method-section" id="method">
        <div className="section-intro method-intro">
          <p className="eyebrow">Method & audit trail</p>
          <h2>What the analysis measures—and what it does not.</h2>
          <p>
            This is a descriptive comparison of Zillow metro and U.S. time series. It measures the estimated share of median household income needed to newly buy or lease the typical home. It does not track the same households over time or identify causal effects.
          </p>
        </div>

        <div className="audit-stats">
          <article><strong>1,700</strong><span>metro-month rows</span></article>
          <article><strong>170</strong><span>months per metro</span></article>
          <article><strong>0</strong><span>duplicate metro-months</span></article>
          <article><strong>11</strong><span>measures audited</span></article>
        </div>

        <div className="method-grid">
          <article>
            <span className="method-number">01</span>
            <h3>Definitions</h3>
            <p><strong>Owner burden</strong> includes mortgage payment, insurance, taxes, and maintenance for a typical home bought with 20% down.</p>
            <p><strong>Renter burden</strong> is the share of median income needed to newly lease the typical rental.</p>
          </article>
          <article>
            <span className="method-number">02</span>
            <h3>Transformations</h3>
            <p>Wide monthly source files were reshaped into a metro-month panel. Currency and count strings were parsed as numeric values; dates were normalized; no missing values were imputed.</p>
          </article>
          <article>
            <span className="method-number">03</span>
            <h3>Interpretation</h3>
            <p>The 30% line is a screening benchmark, not a universal household budget. Metro averages conceal neighborhood, tenure, race, age, and income differences.</p>
          </article>
        </div>

        <div className="coverage-card">
          <div className="panel-heading"><div><p className="micro-label">Coverage audit</p><h3>Not every measure begins in 2012.</h3></div><p>No imputation</p></div>
          <div className="coverage-table" role="table" aria-label="Data coverage by metric">
            <div className="coverage-row header" role="row"><span>Measure</span><span>Starts</span><span>Ends</span><span>Missing</span></div>
            {coverage.map((row) => (
              <div className="coverage-row" role="row" key={row.metric}><strong>{row.metric}</strong><span>{row.start}</span><span>{row.end}</span><span>{row.missing}</span></div>
            ))}
          </div>
        </div>

        <div className="source-note">
          <div><p className="micro-label">Primary source</p><h3>Zillow Research housing data</h3></div>
          <p>ZHVI, ZORI, affordability, inventory, sales, and market-series definitions and downloads. Source series may be revised by Zillow after publication.</p>
          <a href="https://www.zillow.com/research/data/" target="_blank" rel="noreferrer">Review source definitions ↗</a>
        </div>
      </section>

      <footer>
        <p><strong>Bearish on Housing</strong> · A data story by Sasha Schaps</p>
        <p>Analysis through February 2026 · Descriptive, not financial advice</p>
      </footer>
    </main>
  );
}
